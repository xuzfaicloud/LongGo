import { CustomizedAlert } from './CustomizedAlert';

export {
  CustomizedAlert
}
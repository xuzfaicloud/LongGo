import { HowTo } from './HowTo';

export {
  HowTo
};
import { Room } from './Room';

export {
  Room
};
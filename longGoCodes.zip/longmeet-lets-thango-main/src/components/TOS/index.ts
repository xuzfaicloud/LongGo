import { TOS } from './TOS';

export {
  TOS
};
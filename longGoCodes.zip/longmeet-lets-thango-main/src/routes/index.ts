export const ROOT = '/';
export const JOIN = '/join';
export const ROOM = '/room';
export const HOW_TO = '/how';
export const TOS = '/tos';
export const PATREON = 'https://www.patreon.com/thangnguyen';
export const BUY_ME_TEA = 'https://www.buymeacoffee.com/thangnguyen';
export const GIT = 'https://github.com/tnguye20';